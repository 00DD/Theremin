var group__jpopupmenu =
[
    [ "jpopupmenu_additem", "group__jpopupmenu.html#ga1911796fed5dd59d3ab9a7471f6161a9", null ],
    [ "jpopupmenu_addseperator", "group__jpopupmenu.html#gad948b473c9ff12c1159960dcd36fb9a2", null ],
    [ "jpopupmenu_addsubmenu", "group__jpopupmenu.html#ga5ba90215f0693fe446f0f4c64af954b1", null ],
    [ "jpopupmenu_clear", "group__jpopupmenu.html#gaf4f15c09d15aaaa33d149a6109c4aa47", null ],
    [ "jpopupmenu_create", "group__jpopupmenu.html#ga4ee6ff8775c88750bc002db49bdaa98b", null ],
    [ "jpopupmenu_destroy", "group__jpopupmenu.html#ga1481bf544273533000b02e31e42df65f", null ],
    [ "jpopupmenu_popup", "group__jpopupmenu.html#ga53b05326e6d6f2def7573941d97699c0", null ],
    [ "jpopupmenu_popup_abovebox", "group__jpopupmenu.html#ga18c3434bd119af47b3ec605b659c1654", null ],
    [ "jpopupmenu_popup_aboverect", "group__jpopupmenu.html#ga872fac493163389d92cea9f51938bd72", null ],
    [ "jpopupmenu_popup_belowrect", "group__jpopupmenu.html#gab4209d718062281ddfb76ee6ee8e6996", null ],
    [ "jpopupmenu_popup_nearbox", "group__jpopupmenu.html#gab7ff50b3fcc40c38c478f97b1848e099", null ],
    [ "jpopupmenu_setcolors", "group__jpopupmenu.html#gaef73894f17b579c0cc6cc6d56de4ffe5", null ],
    [ "jpopupmenu_setfont", "group__jpopupmenu.html#gaf4a1c2ad6943b5095cac1932f9c39972", null ]
];