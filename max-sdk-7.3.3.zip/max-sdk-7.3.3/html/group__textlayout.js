var group__textlayout =
[
    [ "t_jgraphics_textlayout_flags", "group__textlayout.html#ga9b00aebce7fb7877e7e4c13e18b38f08", [
      [ "JGRAPHICS_TEXTLAYOUT_NOWRAP", "group__textlayout.html#gga9b00aebce7fb7877e7e4c13e18b38f08a2e017ab0c3bba7f02373f6621bee41e8", null ],
      [ "JGRAPHICS_TEXTLAYOUT_USEELLIPSIS", "group__textlayout.html#gga9b00aebce7fb7877e7e4c13e18b38f08a0c76c7621cdb18e19d7ef767e8b71fe5", null ]
    ] ],
    [ "jtextlayout_create", "group__textlayout.html#gaf615694d8a34728f84092838b91e2a4a", null ],
    [ "jtextlayout_createpath", "group__textlayout.html#ga15646278bb10a6cd109359d9e2cc0580", null ],
    [ "jtextlayout_destroy", "group__textlayout.html#ga3bd3ba8982b5b42bcf8870515b708303", null ],
    [ "jtextlayout_draw", "group__textlayout.html#gada972c6fcde61e14fec99a02d88bf131", null ],
    [ "jtextlayout_getchar", "group__textlayout.html#ga6e1b7c2d44d3cbcb051eda74d8e47ef1", null ],
    [ "jtextlayout_getcharbox", "group__textlayout.html#gab251f42f6b58c3dd3d55a3454c82e34a", null ],
    [ "jtextlayout_getnumchars", "group__textlayout.html#ga3a3518a4148d81d2a2aae24e5d60ea24", null ],
    [ "jtextlayout_measuretext", "group__textlayout.html#ga1d16002933b41d956dd7038f0e4bcf0e", null ],
    [ "jtextlayout_set", "group__textlayout.html#gac9d7684376b82def890308ca2ab7ff9e", null ],
    [ "jtextlayout_settext", "group__textlayout.html#gaaff920b11bf2f3d2b3536bbfd5d4c236", null ],
    [ "jtextlayout_settextcolor", "group__textlayout.html#ga73ef3d6927ae63816be07cd3314db191", null ],
    [ "jtextlayout_withbgcolor", "group__textlayout.html#ga97bb1d3ac51e09a5f2c22487a6e170e0", null ]
];