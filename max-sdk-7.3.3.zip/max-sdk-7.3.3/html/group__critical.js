var group__critical =
[
    [ "critical_enter", "group__critical.html#ga246445cffc822f756ac6fb34a055022d", null ],
    [ "critical_exit", "group__critical.html#ga269f46fef96f91143fc1616a4105984c", null ],
    [ "critical_free", "group__critical.html#gaedbe0cba11940710c789ac01194e3712", null ],
    [ "critical_new", "group__critical.html#gaaa373bcd9c8059e4887225aaf32a76d2", null ],
    [ "critical_tryenter", "group__critical.html#ga0a4109d5c2b82f0c1022015abac175dc", null ],
    [ "t_critical", "group__critical.html#ga8d715cd96234700ea62572e0d19e27e6", null ]
];