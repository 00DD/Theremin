var group__jwind =
[
    [ "jwind_getactive", "group__jwind.html#ga607f8f4486ff1588ff47c17df61f8af1", null ],
    [ "jwind_getat", "group__jwind.html#ga6a7b4f369dfdd3e17e9509cec7bdbb64", null ],
    [ "jwind_getcount", "group__jwind.html#gae627d232548eaefbe00a94ff3c5a1cb6", null ]
];