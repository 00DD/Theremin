var group__class__old =
[
    [ "addbang", "group__class__old.html#gac667faa21ecad5184005266844ed0b48", null ],
    [ "addfloat", "group__class__old.html#ga1e2089acfa6856835613d130a5b6bd7d", null ],
    [ "addftx", "group__class__old.html#gad223143c8da12d8f3b7b18f9d6e5da9e", null ],
    [ "addint", "group__class__old.html#ga85afc0cd451465117ac80593d3deb4f9", null ],
    [ "addinx", "group__class__old.html#gad3a69b2d38b257464c6a0f8a50efd85a", null ],
    [ "addmess", "group__class__old.html#ga0d9bfa416fdd861d1b2fd2d17701cbb3", null ],
    [ "alias", "group__class__old.html#gad8f119f6232340c85b3bb358227576b3", null ],
    [ "class_setname", "group__class__old.html#gafb05186b12fb0dceeb3185b2f59b6307", null ],
    [ "egetfn", "group__class__old.html#ga96dfd8b6f4c7111c34f1c2103fbdcdf0", null ],
    [ "freeobject", "group__class__old.html#gadf30646e52376a37b93cc20efac65636", null ],
    [ "getfn", "group__class__old.html#gafa477f96b3a02c0ecbca2b5aa14b9ecb", null ],
    [ "newinstance", "group__class__old.html#ga4c1f100a92d6f519ba4e93665ff54998", null ],
    [ "newobject", "group__class__old.html#ga053f428d5edcc7d663980330848e73a6", null ],
    [ "setup", "group__class__old.html#ga807841ecd0a4cb572e33a8496f208e96", null ],
    [ "typedmess", "group__class__old.html#ga78c60eb0068bce55eaa635e206cba52e", null ],
    [ "zgetfn", "group__class__old.html#ga54a45bcc841c2033467be14e6861b548", null ]
];