var group__ui =
[
    [ "JGraphics", "group__jgraphics.html", "group__jgraphics" ],
    [ "DataView", "group__jdataview.html", "group__jdataview" ]
];