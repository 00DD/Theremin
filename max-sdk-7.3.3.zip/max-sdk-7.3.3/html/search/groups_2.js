var searchData=
[
  ['classes',['Classes',['../group__class.html',1,'']]],
  ['class_20module',['Class Module',['../group__classmod.html',1,'']]],
  ['clocks',['Clocks',['../group__clocks.html',1,'']]],
  ['colors',['Colors',['../group__color.html',1,'']]],
  ['console',['Console',['../group__console.html',1,'']]],
  ['critical_20regions',['Critical Regions',['../group__critical.html',1,'']]]
];
