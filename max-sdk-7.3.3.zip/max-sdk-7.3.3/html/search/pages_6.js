var searchData=
[
  ['matrix_20operator_20details',['Matrix Operator Details',['../chapter_jit_mopdetails.html',1,'']]],
  ['matrix_20operator_20quickstart',['Matrix Operator QuickStart',['../chapter_jit_mopqs.html',1,'']]],
  ['memory_20allocation',['Memory Allocation',['../chapter_memory.html',1,'']]]
];
