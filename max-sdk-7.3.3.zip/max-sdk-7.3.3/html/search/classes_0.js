var searchData=
[
  ['_5fbuffer',['_buffer',['../struct__buffer.html',1,'']]]
];
