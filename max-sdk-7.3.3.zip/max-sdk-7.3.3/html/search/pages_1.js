var searchData=
[
  ['data_20structures',['Data Structures',['../chapter_datastructures.html',1,'']]],
  ['drag_27n_27drop',['Drag&apos;n&apos;Drop',['../chapter_dragndrop.html',1,'']]],
  ['development_20system_20information',['Development System Information',['../chapter_platform.html',1,'']]]
];
