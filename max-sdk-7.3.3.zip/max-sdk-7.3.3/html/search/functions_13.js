var searchData=
[
  ['wind_5fadvise',['wind_advise',['../group__misc.html#gab127ce8d89ae72d420a44642c52cc94d',1,'ext_wind.h']]],
  ['wind_5fsetcursor',['wind_setcursor',['../group__misc.html#ga85a1754ef77207af4ab7617e7487336e',1,'ext_wind.h']]]
];
