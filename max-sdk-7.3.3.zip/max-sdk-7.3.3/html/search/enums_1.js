var searchData=
[
  ['hittestresult',['HitTestResult',['../group__jbox.html#ga956a254a140565aa9ff36a514740e021',1,'jpatcher_api.h']]]
];
