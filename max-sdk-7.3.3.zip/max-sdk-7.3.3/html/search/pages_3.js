var searchData=
[
  ['file_20handling',['File Handling',['../chapter_files.html',1,'']]]
];
