var searchData=
[
  ['scheduler_20and_20low_20priority_20queue_20issues',['Scheduler and Low Priority Queue Issues',['../chapter_jit_sched.html',1,'']]],
  ['sending_20messages_2c_20calling_20methods',['Sending Messages, Calling Methods',['../chapter_msgattached.html',1,'']]],
  ['scripting_20the_20patcher',['Scripting the Patcher',['../chapter_scripting.html',1,'']]]
];
