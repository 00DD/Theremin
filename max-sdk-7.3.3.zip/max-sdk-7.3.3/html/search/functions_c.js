var searchData=
[
  ['newhandle',['newhandle',['../group__memory.html#ga50135e5f9bb18030ff1d12e9976253ab',1,'ext_proto.h']]],
  ['newinstance',['newinstance',['../group__class__old.html#ga4c1f100a92d6f519ba4e93665ff54998',1,'ext_proto.h']]],
  ['newobject',['newobject',['../group__class__old.html#ga053f428d5edcc7d663980330848e73a6',1,'ext_proto.h']]],
  ['newobject_5ffromboxtext',['newobject_fromboxtext',['../group__obj.html#ga9afc2f1b4cbdd3a2ccdc37de0e4146d6',1,'ext_dictionary.h']]],
  ['newobject_5ffromdictionary',['newobject_fromdictionary',['../group__obj.html#gaed2c4e1d0c80d929b97ccf07a886faeb',1,'ext_dictionary.h']]],
  ['newobject_5fsprintf',['newobject_sprintf',['../group__obj.html#gaa7fbd3be9a16b2abf1e5a27fec9cff74',1,'ext_dictionary.h']]]
];
