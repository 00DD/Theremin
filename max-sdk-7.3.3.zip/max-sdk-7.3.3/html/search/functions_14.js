var searchData=
[
  ['z_5fdsp_5ffree',['z_dsp_free',['../group__msp.html#ga85762f03c915d3860f526a8bf4dd1f3f',1,'z_dsp.h']]],
  ['z_5fdsp_5fsetup',['z_dsp_setup',['../group__msp.html#ga5c4d70cfb420f13386dd1473143e5825',1,'z_dsp.h']]],
  ['zgetfn',['zgetfn',['../group__class__old.html#ga54a45bcc841c2033467be14e6861b548',1,'ext_proto.h']]]
];
