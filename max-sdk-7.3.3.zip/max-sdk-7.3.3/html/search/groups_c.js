var searchData=
[
  ['popup_20menus',['Popup Menus',['../group__jpopupmenu.html',1,'']]],
  ['parallel_20utility_20module',['Parallel Utility Module',['../group__parallelutilmod.html',1,'']]],
  ['patcher',['Patcher',['../group__patcher.html',1,'']]],
  ['pfft',['PFFT',['../group__pfft.html',1,'']]],
  ['poly',['Poly',['../group__poly.html',1,'']]],
  ['presets',['Presets',['../group__presets.html',1,'']]]
];
