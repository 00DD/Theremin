var searchData=
[
  ['extending_20expr',['Extending expr',['../group__expr.html',1,'']]]
];
