var searchData=
[
  ['name',['name',['../structt__jit__attribute.html#a9d73ebbafed2d8da2a971962e5ccfeff',1,'t_jit_attribute::name()'],['../structt__jit__attr__offset.html#a0972d52a5b1ab0b054222cba18d98430',1,'t_jit_attr_offset::name()'],['../structt__jit__attr__offset__array.html#a2bc8326087aa9bfb338172f56ce384c9',1,'t_jit_attr_offset_array::name()'],['../structt__jit__attr.html#ae44dfc755dd3a5c525826114d5bd6a64',1,'t_jit_attr::name()'],['../structt__jit__gl__context__view.html#a564629275a660ed2949bb9cc6722355a',1,'t_jit_gl_context_view::name()']]],
  ['newhandle',['newhandle',['../group__memory.html#ga50135e5f9bb18030ff1d12e9976253ab',1,'ext_proto.h']]],
  ['newinstance',['newinstance',['../group__class__old.html#ga4c1f100a92d6f519ba4e93665ff54998',1,'ext_proto.h']]],
  ['newobject',['newobject',['../group__class__old.html#ga053f428d5edcc7d663980330848e73a6',1,'ext_proto.h']]],
  ['newobject_5ffromboxtext',['newobject_fromboxtext',['../group__obj.html#ga9afc2f1b4cbdd3a2ccdc37de0e4146d6',1,'ext_dictionary.h']]],
  ['newobject_5ffromdictionary',['newobject_fromdictionary',['../group__obj.html#gaed2c4e1d0c80d929b97ccf07a886faeb',1,'ext_dictionary.h']]],
  ['newobject_5fsprintf',['newobject_sprintf',['../group__obj.html#gaa7fbd3be9a16b2abf1e5a27fec9cff74',1,'ext_dictionary.h']]],
  ['next_5fchunk',['next_chunk',['../structt__jit__glchunk.html#a1efaf20ab86826159f4f0dfd3622ea06',1,'t_jit_glchunk']]],
  ['nogood',['NOGOOD',['../group__obj.html#gabf8c1d20a4f4e731d185c02820c91593',1,'ext_mess.h']]]
];
