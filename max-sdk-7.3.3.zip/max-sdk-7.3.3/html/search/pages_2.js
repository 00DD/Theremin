var searchData=
[
  ['enhancements_20to_20objects',['Enhancements to Objects',['../chapter_enhancements.html',1,'']]]
];
