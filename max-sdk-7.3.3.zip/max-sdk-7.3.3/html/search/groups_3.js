var searchData=
[
  ['database',['Database',['../group__database.html',1,'']]],
  ['data_20storage',['Data Storage',['../group__datastore.html',1,'']]],
  ['data_20types',['Data Types',['../group__datatypes.html',1,'']]],
  ['dictionary',['Dictionary',['../group__dictionary.html',1,'']]],
  ['dictionary_20passing_20api',['Dictionary Passing API',['../group__dictobj.html',1,'']]],
  ['dataview',['DataView',['../group__jdataview.html',1,'']]]
];
