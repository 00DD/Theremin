var searchData=
[
  ['max_5ferr_5fduplicate',['MAX_ERR_DUPLICATE',['../group__misc.html#gga0764dd6c02b76cca7d053ae50555d69da9b67faa1ffafc9b60748135e48b105d1',1,'ext_obex.h']]],
  ['max_5ferr_5fgeneric',['MAX_ERR_GENERIC',['../group__misc.html#gga0764dd6c02b76cca7d053ae50555d69dae285bdd436f17560cfd09c6b31ea397d',1,'ext_obex.h']]],
  ['max_5ferr_5finvalid_5fptr',['MAX_ERR_INVALID_PTR',['../group__misc.html#gga0764dd6c02b76cca7d053ae50555d69da42a29c15166206a1bbc13bcc74b2c651',1,'ext_obex.h']]],
  ['max_5ferr_5fnone',['MAX_ERR_NONE',['../group__misc.html#gga0764dd6c02b76cca7d053ae50555d69da6d22f77fef8b1e1b074cef5d29d935fd',1,'ext_obex.h']]],
  ['max_5ferr_5fout_5fof_5fmem',['MAX_ERR_OUT_OF_MEM',['../group__misc.html#gga0764dd6c02b76cca7d053ae50555d69da5415d3c3fa523e0bb2ed1edfdbfce9be',1,'ext_obex.h']]]
];
