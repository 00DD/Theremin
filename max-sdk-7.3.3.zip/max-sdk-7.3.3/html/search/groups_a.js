var searchData=
[
  ['monitors_20and_20displays',['Monitors and Displays',['../group__jmonitor.html',1,'']]],
  ['mouse_20and_20keyboard',['Mouse and Keyboard',['../group__jmouse.html',1,'']]],
  ['math_20module',['Math Module',['../group__mathmod.html',1,'']]],
  ['matrix_20module',['Matrix Module',['../group__matrixmod.html',1,'']]],
  ['mop_20max_20wrapper_20module',['MOP Max Wrapper Module',['../group__maxmopmod.html',1,'']]],
  ['max_20wrapper_20module',['Max Wrapper Module',['../group__maxwrapmod.html',1,'']]],
  ['memory_20management',['Memory Management',['../group__memory.html',1,'']]],
  ['memory_20module',['Memory Module',['../group__memorymod.html',1,'']]],
  ['miscellaneous',['Miscellaneous',['../group__misc.html',1,'']]],
  ['mop_20module',['MOP Module',['../group__mopmod.html',1,'']]],
  ['msp',['MSP',['../group__msp.html',1,'']]],
  ['mutexes',['Mutexes',['../group__mutex.html',1,'']]],
  ['miscellaneous_20utility_20module',['Miscellaneous Utility Module',['../group__utilitymod.html',1,'']]]
];
