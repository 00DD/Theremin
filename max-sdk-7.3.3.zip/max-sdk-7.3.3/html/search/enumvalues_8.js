var searchData=
[
  ['sys_5fmaxblksize',['SYS_MAXBLKSIZE',['../group__msp.html#ggaaf8fd5f0e57d456151c951e0f3715fc4a29738f7ba126b5468181b4c017e573d0',1,'z_dsp.h']]],
  ['sys_5fmaxsigs',['SYS_MAXSIGS',['../group__msp.html#ggaaf8fd5f0e57d456151c951e0f3715fc4a00acca9cc1491d6006a4c38127f02a90',1,'z_dsp.h']]],
  ['sysdateformat_5fflags_5flong',['SYSDATEFORMAT_FLAGS_LONG',['../group__systime.html#gga26a8d02aa000843530dcb2d350766951a0cdecdf057e390773e60c3d71de7faf4',1,'ext_systime.h']]],
  ['sysdateformat_5fflags_5fmedium',['SYSDATEFORMAT_FLAGS_MEDIUM',['../group__systime.html#gga26a8d02aa000843530dcb2d350766951a44be9bae61adf4f4b802989465768d63',1,'ext_systime.h']]],
  ['sysdateformat_5fflags_5fshort',['SYSDATEFORMAT_FLAGS_SHORT',['../group__systime.html#gga26a8d02aa000843530dcb2d350766951a03c806745c3aad02d768797ead649e20',1,'ext_systime.h']]],
  ['sysfile_5fatmark',['SYSFILE_ATMARK',['../group__files.html#ggaa0726cf3525f28c2bba73401193c430ea912f3ce009e04501285d5e029edef84a',1,'ext_sysfile.h']]],
  ['sysfile_5ffromleof',['SYSFILE_FROMLEOF',['../group__files.html#ggaa0726cf3525f28c2bba73401193c430ea25ca6f4d91093fcf6ae3646376c7433c',1,'ext_sysfile.h']]],
  ['sysfile_5ffrommark',['SYSFILE_FROMMARK',['../group__files.html#ggaa0726cf3525f28c2bba73401193c430ea016f69a42070b5f2babbb1edd4fb27c0',1,'ext_sysfile.h']]],
  ['sysfile_5ffromstart',['SYSFILE_FROMSTART',['../group__files.html#ggaa0726cf3525f28c2bba73401193c430eaf0d10ac5a565be0a7af62c2ed4ca16ec',1,'ext_sysfile.h']]],
  ['systhread_5fmutex_5ferrorcheck',['SYSTHREAD_MUTEX_ERRORCHECK',['../group__threading.html#ggaa95d9c538a1b25404d19106739db9802abb3854e7bf495808b4251d1319cdfa45',1,'ext_systhread.h']]],
  ['systhread_5fmutex_5fnormal',['SYSTHREAD_MUTEX_NORMAL',['../group__threading.html#ggaa95d9c538a1b25404d19106739db9802ae34f8741b28ee92a4d702bee8671bb32',1,'ext_systhread.h']]],
  ['systhread_5fmutex_5frecursive',['SYSTHREAD_MUTEX_RECURSIVE',['../group__threading.html#ggaa95d9c538a1b25404d19106739db9802a4fa486d028b3153aac389ed24e63dddb',1,'ext_systhread.h']]]
];
