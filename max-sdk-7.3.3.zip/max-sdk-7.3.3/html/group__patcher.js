var group__patcher =
[
    [ "jpatcher", "group__jpatcher.html", "group__jpatcher" ],
    [ "jbox", "group__jbox.html", "group__jbox" ],
    [ "jpatchline", "group__jpatchline.html", "group__jpatchline" ],
    [ "jpatcherview", "group__jpatcherview.html", "group__jpatcherview" ],
    [ "t_jbox", "structt__jbox.html", null ],
    [ "t_box", "group__patcher.html#ga4ae1309e71747dc0dc5c2baba5e47bc9", [
      [ "PI_DEEP", "group__patcher.html#ggadc29c2ff13d900c2f185ee95427fb06ca615ccc19640c4714e619315b94765e48", null ],
      [ "PI_REQUIREFIRSTIN", "group__patcher.html#ggadc29c2ff13d900c2f185ee95427fb06ca4c42ad2b13496b1d6664fed514724ffa", null ],
      [ "PI_WANTBOX", "group__patcher.html#ggadc29c2ff13d900c2f185ee95427fb06ca128de369dd62c2625aff042d820456eb", null ]
    ] ],
    [ "t_patcher", "group__patcher.html#ga1c34fe7546d5c8a9a00e8fa17f85e66e", null ]
];