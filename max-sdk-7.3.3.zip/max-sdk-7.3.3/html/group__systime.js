var group__systime =
[
    [ "t_datetime", "structt__datetime.html", [
      [ "day", "structt__datetime.html#a0e45cee31731fe05a42b94e230c4b2a5", null ],
      [ "hour", "structt__datetime.html#a7fcb8ca3508875bcec639acf8d4789fa", null ],
      [ "millisecond", "structt__datetime.html#ae6acb513ff7429073f38185d48207757", null ],
      [ "minute", "structt__datetime.html#a593b374ce9ec380838b9c555369d8308", null ],
      [ "month", "structt__datetime.html#a0120c515b613a5ff62a57a705438461b", null ],
      [ "second", "structt__datetime.html#ad1fa5606f28662caf05aeaa24b2459f4", null ],
      [ "year", "structt__datetime.html#add45b92ce37bfe09335c2e9a939e8905", null ]
    ] ],
    [ "e_max_dateflags", "group__systime.html#ga26a8d02aa000843530dcb2d350766951", [
      [ "SYSDATEFORMAT_FLAGS_SHORT", "group__systime.html#gga26a8d02aa000843530dcb2d350766951a03c806745c3aad02d768797ead649e20", null ],
      [ "SYSDATEFORMAT_FLAGS_MEDIUM", "group__systime.html#gga26a8d02aa000843530dcb2d350766951a44be9bae61adf4f4b802989465768d63", null ],
      [ "SYSDATEFORMAT_FLAGS_LONG", "group__systime.html#gga26a8d02aa000843530dcb2d350766951a0cdecdf057e390773e60c3d71de7faf4", null ]
    ] ],
    [ "sysdateformat_formatdatetime", "group__systime.html#ga6219d6f6543e65431086c34c35199e82", null ],
    [ "sysdateformat_strftimetodatetime", "group__systime.html#ga18e6eef81290f753a997dd6d0019ab60", null ],
    [ "systime_datetime", "group__systime.html#ga53bc85cf0868e8712f32ee846642ab83", null ],
    [ "systime_datetime_milliseconds", "group__systime.html#ga734e64cb0ac24b8fa60138e28ec47786", null ],
    [ "systime_datetoseconds", "group__systime.html#ga6bb87fe4630cfad76f896793bf0d7d48", null ],
    [ "systime_ms", "group__systime.html#ga2078a3dcd793369438992b44d14ca663", null ],
    [ "systime_seconds", "group__systime.html#ga4c695e5b297933f9becb2c9060f9f0de", null ],
    [ "systime_secondstodate", "group__systime.html#ga133d4760ffd03ddab8de058294299b95", null ],
    [ "systime_ticks", "group__systime.html#ga668322a4444daf8e0f69c1cfb32a0c9f", null ]
];