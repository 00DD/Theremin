var group__jmonitor =
[
    [ "jmonitor_getdisplayrect", "group__jmonitor.html#gac11ee33880f15ef641236e864978d9af", null ],
    [ "jmonitor_getdisplayrect_foralldisplays", "group__jmonitor.html#ga0ed7c2c443ef010c4584096967f3b00f", null ],
    [ "jmonitor_getdisplayrect_forpoint", "group__jmonitor.html#ga354f8b2efda018ec3ff2a609205a74a0", null ],
    [ "jmonitor_getnumdisplays", "group__jmonitor.html#ga2bd6c2e27e9ac7bfdd05cbf815ef1082", null ]
];