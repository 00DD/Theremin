var modules =
[
    [ "Attributes", "group__attr.html", "group__attr" ],
    [ "Classes", "group__class.html", "group__class" ],
    [ "Data Storage", "group__datastore.html", "group__datastore" ],
    [ "Data Types", "group__datatypes.html", "group__datatypes" ],
    [ "Files and Folders", "group__files.html", "group__files" ],
    [ "Jitter", "group__jitter.html", "group__jitter" ],
    [ "Memory Management", "group__memory.html", "group__memory" ],
    [ "Miscellaneous", "group__misc.html", "group__misc" ],
    [ "MSP", "group__msp.html", "group__msp" ],
    [ "Objects", "group__obj.html", "group__obj" ],
    [ "Patcher", "group__patcher.html", "group__patcher" ],
    [ "Timing", "group__sched.html", "group__sched" ],
    [ "Threads", "group__threading.html", "group__threading" ],
    [ "User Interface", "group__ui.html", "group__ui" ],
    [ "Unicode", "group__unicode.html", "group__unicode" ]
];