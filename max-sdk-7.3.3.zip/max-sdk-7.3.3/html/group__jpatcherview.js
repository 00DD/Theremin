var group__jpatcherview =
[
    [ "patcherview_canvas_to_screen", "group__jpatcherview.html#gad01b5effb2aabae6ab28ef1e07b705dc", null ],
    [ "patcherview_findpatcherview", "group__jpatcherview.html#ga143a54662c1dea4f8170c7b62bc4cb2d", null ],
    [ "patcherview_get_jgraphics", "group__jpatcherview.html#ga221544b77a5371897c96f2e94ae49c82", null ],
    [ "patcherview_get_locked", "group__jpatcherview.html#ga1b78b4ec463f113a0c2778dbebcc8654", null ],
    [ "patcherview_get_nextview", "group__jpatcherview.html#ga37810ea052b4ecd3598cd687666c8841", null ],
    [ "patcherview_get_patcher", "group__jpatcherview.html#ga056a0684b79a940b8ee71145d9f77223", null ],
    [ "patcherview_get_presentation", "group__jpatcherview.html#ga196c47fa60725d496c75b400da72d8a9", null ],
    [ "patcherview_get_rect", "group__jpatcherview.html#ga310590cbb1dd9fbe5c8c228e35fe11ef", null ],
    [ "patcherview_get_topview", "group__jpatcherview.html#ga2330cebe03e78ad85b47c52e5b979954", null ],
    [ "patcherview_get_visible", "group__jpatcherview.html#gaf9621ecabdae9fc9d865bd42a8bc43a9", null ],
    [ "patcherview_get_zoomfactor", "group__jpatcherview.html#ga3d82e2665c64f9c4452d1737c1429293", null ],
    [ "patcherview_screen_to_canvas", "group__jpatcherview.html#ga8d75b6a4eeea37a70f82b044609b0c70", null ],
    [ "patcherview_set_locked", "group__jpatcherview.html#ga826eb120924785345d8a7851d31ce788", null ],
    [ "patcherview_set_presentation", "group__jpatcherview.html#ga349cf62e72891016e0dcf8ab51c00a62", null ],
    [ "patcherview_set_rect", "group__jpatcherview.html#ga6025a5acb336aa81a0aad67e9de5bbca", null ],
    [ "patcherview_set_visible", "group__jpatcherview.html#gab8b3bb74c2341f42a1b8fb3a1dbdcbb8", null ],
    [ "patcherview_set_zoomfactor", "group__jpatcherview.html#ga5006e672580027e9ae56c49ca3148c3c", null ]
];