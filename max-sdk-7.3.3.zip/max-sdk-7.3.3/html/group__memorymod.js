var group__memorymod =
[
    [ "jit_copy_bytes", "group__memorymod.html#ga84ae88848dbd4c60b8e368773ac0ca92", null ],
    [ "jit_disposeptr", "group__memorymod.html#gaa5a4969fb76823dd0c3a679a5bd01222", null ],
    [ "jit_freebytes", "group__memorymod.html#ga4a6a1b9a98f66b50735f69e6acf64af0", null ],
    [ "jit_freemem", "group__memorymod.html#gad1723114dcc67cbb24e45cb59aa0bb4f", null ],
    [ "jit_getbytes", "group__memorymod.html#ga348f78687a0aabb79d772d633cc679cc", null ],
    [ "jit_handle_free", "group__memorymod.html#ga2710dd7978b8e7f406b525261fb42346", null ],
    [ "jit_handle_lock", "group__memorymod.html#ga8beac43ecbe453e810b373739bbf1483", null ],
    [ "jit_handle_new", "group__memorymod.html#ga09f5e82fafd1de78638c36105860a635", null ],
    [ "jit_handle_size_get", "group__memorymod.html#gac31e411720c7f4c3ed1d6d9e4bebd513", null ],
    [ "jit_handle_size_set", "group__memorymod.html#ga326dbdb81cd24ec26384845cd624af7b", null ],
    [ "jit_newptr", "group__memorymod.html#ga7c7f1fc4d1e935c154eb285c9216623b", null ]
];