var group__jpattern =
[
    [ "t_jpattern", "group__jpattern.html#ga09985abaac3992df8e5985e219191c7d", null ]
];