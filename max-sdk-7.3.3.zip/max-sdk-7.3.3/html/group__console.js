var group__console =
[
    [ "cpost", "group__console.html#ga886480909fef7706c7181362a78fa19e", null ],
    [ "error", "group__console.html#ga8a87d2e25431900a88722759ec115757", null ],
    [ "object_error", "group__console.html#ga7622564965cfebaf51169ce60175504a", null ],
    [ "object_error_obtrusive", "group__console.html#ga1b21065ce872a531889861eb937077e2", null ],
    [ "object_post", "group__console.html#gac8e59004be8d946b6812140cb0a33fb0", null ],
    [ "object_warn", "group__console.html#ga5f9b8c5b0ecb1ec909fcbb8f498b0759", null ],
    [ "ouchstring", "group__console.html#ga6e2c274bdadea42658de309ce129b017", null ],
    [ "post", "group__console.html#ga8eebb1400d598f4423f925102d02970a", null ],
    [ "postatom", "group__console.html#gaef84325d992e0afa14b2e7b0c0515601", null ]
];