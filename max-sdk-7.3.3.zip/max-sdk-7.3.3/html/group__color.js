var group__color =
[
    [ "t_jrgb", "structt__jrgb.html", [
      [ "blue", "structt__jrgb.html#a67f8352f8ce662eab024c3fa62b0138f", null ],
      [ "green", "structt__jrgb.html#ac91479ca6fa91e1e15c9ec38f37122fe", null ],
      [ "red", "structt__jrgb.html#ac5be259bd02917a292fb8690e4db6a08", null ]
    ] ],
    [ "t_jrgba", "structt__jrgba.html", [
      [ "alpha", "structt__jrgba.html#a04f9ec088510b4d0faf52bc42357550b", null ],
      [ "green", "structt__jrgba.html#a2055e7618635a250b70d4f724894ab52", null ],
      [ "red", "structt__jrgba.html#a94003046e8f727489b81a1804939e28d", null ]
    ] ],
    [ "atoms_to_jrgba", "group__color.html#ga78325ce33d8e74c79c4f1adeef3e36f7", null ],
    [ "jrgba_attr_get", "group__color.html#ga27b52b9c7e3b8e9fafccdfcb4caee127", null ],
    [ "jrgba_attr_set", "group__color.html#ga22c35beb59c7430d6c6e25e6e1fdb8c9", null ],
    [ "jrgba_compare", "group__color.html#ga585ffc0ec76fe1b5d0e1c50e8eef0b39", null ],
    [ "jrgba_copy", "group__color.html#ga24a7d1e24d38a91ab8aa02a48e5da70e", null ],
    [ "jrgba_set", "group__color.html#ga322f6e69277981f02effe1212affed3c", null ],
    [ "jrgba_to_atoms", "group__color.html#ga847dd3f1a2640660f12a14fab259afa8", null ]
];