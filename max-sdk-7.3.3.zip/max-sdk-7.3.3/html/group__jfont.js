var group__jfont =
[
    [ "t_jfont", "group__jfont.html#ga75f83f853e52af957c799723cac89ae5", null ],
    [ "t_jgraphics_font_slant", "group__jfont.html#gaea63403193677b088b56cb60c69c37b4", [
      [ "JGRAPHICS_FONT_SLANT_NORMAL", "group__jfont.html#ggaea63403193677b088b56cb60c69c37b4a42c9269c412c5cfaf42db4db88add2a8", null ],
      [ "JGRAPHICS_FONT_SLANT_ITALIC", "group__jfont.html#ggaea63403193677b088b56cb60c69c37b4a66269b2de097def1c7d8100683cae0da", null ]
    ] ],
    [ "t_jgraphics_font_weight", "group__jfont.html#ga29fc4356e11166a16aeae50dd5e22f86", [
      [ "JGRAPHICS_FONT_WEIGHT_NORMAL", "group__jfont.html#gga29fc4356e11166a16aeae50dd5e22f86a9877f7707c8073709254be3d6429909a", null ],
      [ "JGRAPHICS_FONT_WEIGHT_BOLD", "group__jfont.html#gga29fc4356e11166a16aeae50dd5e22f86aa12c9a0fb782696b77e2d991712e5761", null ]
    ] ],
    [ "jbox_get_font_slant", "group__jfont.html#ga98bc2063c505fb26829605e940ffc6d4", null ],
    [ "jbox_get_font_weight", "group__jfont.html#gabff7a5c0793cab2aed118f82ab3d520a", null ],
    [ "jfont_create", "group__jfont.html#gae09cf4470873157407375af651cabcff", null ],
    [ "jfont_destroy", "group__jfont.html#gaec794a3e2e240f8b759f525c756e7f33", null ],
    [ "jfont_extents", "group__jfont.html#ga244f386f53aef62b283ff492adc50a73", null ],
    [ "jfont_get_em_dimensions", "group__jfont.html#gabbce99abbd3e85f4b35a5892da6c9866", null ],
    [ "jfont_get_family", "group__jfont.html#ga4f60d85caec22d9ab7d76619d2384eec", null ],
    [ "jfont_get_font_size", "group__jfont.html#ga9abf4aaabe169709ce4c4eb523a802ec", null ],
    [ "jfont_get_slant", "group__jfont.html#ga8d1b26854b198b3856dcd73ee03e948c", null ],
    [ "jfont_get_underline", "group__jfont.html#ga40a81e34a5ed6d878c063c0f42210487", null ],
    [ "jfont_get_weight", "group__jfont.html#gaf9ef6480f2ec7d085eff222c0b251649", null ],
    [ "jfont_getfontlist", "group__jfont.html#gaa796e25612596182442bc072e457310d", null ],
    [ "jfont_isequalto", "group__jfont.html#ga784707fd739dfe418fe662551fbc0b7a", null ],
    [ "jfont_reference", "group__jfont.html#gaa3cdecfe931e80252a71bb6b2a9ee1f8", null ],
    [ "jfont_set_family", "group__jfont.html#ga0f7b5fc19f5f9a0e4d1dcccf7a55a57e", null ],
    [ "jfont_set_font_size", "group__jfont.html#ga5857efa47dcf9dbc1822f7500c4aa5b3", null ],
    [ "jfont_set_slant", "group__jfont.html#ga2417a53015e8d3c75e59f6db63d62f6c", null ],
    [ "jfont_set_underline", "group__jfont.html#ga40e5705b583cf366c6b7a23a88df9050", null ],
    [ "jfont_set_weight", "group__jfont.html#gaf9e0b85896193489682b019d67a56579", null ],
    [ "jfont_text_measure", "group__jfont.html#gad587e956e70581198b075cb336b4ccce", null ],
    [ "jfont_text_measuretext_wrapped", "group__jfont.html#ga9db6688289427ac765b5ff3b48039aef", null ],
    [ "systemfontname", "group__jfont.html#gafa70864b20c34d1c67e87dcd1eaeab4a", null ],
    [ "systemfontname_bold", "group__jfont.html#ga495a1971236bb1325b2528d9ded54a4e", null ],
    [ "systemfontname_light", "group__jfont.html#gac934f86b897046ba414f69e15e8f7253", null ],
    [ "systemfontsym", "group__jfont.html#gaecc09a42c4a99d0a7ae0ed86899f5b78", null ]
];