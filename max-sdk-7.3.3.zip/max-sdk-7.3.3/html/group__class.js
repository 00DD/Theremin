var group__class =
[
    [ "Old-Style Classes", "group__class__old.html", "group__class__old" ],
    [ "Inlets and Outlets", "group__inout.html", "group__inout" ],
    [ "t_class", "structt__class.html", [
      [ "c_filename", "structt__class.html#afbc0e6fa8637f7207f813d809df61a05", null ],
      [ "c_sym", "structt__class.html#acd4e149d4405cca175f994ead1ca51fb", null ]
    ] ],
    [ "CLASS_BOX", "group__class.html#gaf640c99a1fceb8158c2d1e77381b0320", null ],
    [ "CLASS_NOBOX", "group__class.html#ga090d3cbc4f137661806fc1b72249a791", null ],
    [ "e_max_class_flags", "group__class.html#ga124a08e1744d9e999211abaa9df9f556", [
      [ "CLASS_FLAG_BOX", "group__class.html#gga124a08e1744d9e999211abaa9df9f556af008530d0bd6c2091fe85923e412834f", null ],
      [ "CLASS_FLAG_POLYGLOT", "group__class.html#gga124a08e1744d9e999211abaa9df9f556ac72d734fc04a3c47be53a77b1682b753", null ],
      [ "CLASS_FLAG_NEWDICTIONARY", "group__class.html#gga124a08e1744d9e999211abaa9df9f556aab2bebd8a64110247fa11db1c13ca5eb", null ],
      [ "CLASS_FLAG_REGISTERED", "group__class.html#gga124a08e1744d9e999211abaa9df9f556a2ecc4a934743139d88d39fc62d028614", null ],
      [ "CLASS_FLAG_UIOBJECT", "group__class.html#gga124a08e1744d9e999211abaa9df9f556acdc1b6c10a366457cca2ea5e01964d80", null ],
      [ "CLASS_FLAG_ALIAS", "group__class.html#gga124a08e1744d9e999211abaa9df9f556aa44754fe97e81d80049c2647fb4d6a62", null ],
      [ "CLASS_FLAG_DO_NOT_PARSE_ATTR_ARGS", "group__class.html#gga124a08e1744d9e999211abaa9df9f556a99981e2a6df832c0f59871193f2060a5", null ],
      [ "CLASS_FLAG_DO_NOT_ZERO", "group__class.html#gga124a08e1744d9e999211abaa9df9f556ae6233c38c0dbacbc12b6ff152803c9cb", null ],
      [ "CLASS_FLAG_NOATTRIBUTES", "group__class.html#gga124a08e1744d9e999211abaa9df9f556aa8a5af40c8083496ee03dd3480087eee", null ],
      [ "CLASS_FLAG_OWNATTRIBUTES", "group__class.html#gga124a08e1744d9e999211abaa9df9f556a2c12440c31196a04f5ab4883a2334659", null ],
      [ "CLASS_FLAG_PARAMETER", "group__class.html#gga124a08e1744d9e999211abaa9df9f556a07a14e2f32bd185dd34742d77c8e2eb8", null ],
      [ "CLASS_FLAG_RETYPEABLE", "group__class.html#gga124a08e1744d9e999211abaa9df9f556ad06351e541da166e4924c27abb81151a", null ],
      [ "CLASS_FLAG_OBJECT_METHOD", "group__class.html#gga124a08e1744d9e999211abaa9df9f556aa4be223531ae66209bf2d37a1c18dd79", null ]
    ] ],
    [ "class_addattr", "group__class.html#ga2289eb7e26b552be6e015c2f9912a9ac", null ],
    [ "class_addmethod", "group__class.html#gaab2e3c25868317c8a9c216bbca2c040d", null ],
    [ "class_alias", "group__class.html#gab6f0ce5c584100e70106404e6068ac0d", null ],
    [ "class_dumpout_wrap", "group__class.html#ga1b3d0a6942c49af47e3f44031d8f1097", null ],
    [ "class_findbyname", "group__class.html#ga11d93886daa53a3e0dea974176190301", null ],
    [ "class_findbyname_casefree", "group__class.html#gacfffc94c91ff5254f8acc363be75b577", null ],
    [ "class_free", "group__class.html#ga1df757149b7ad2f1d37178c5c184935f", null ],
    [ "class_is_ui", "group__class.html#ga8c3f01e90f8adbc3c9b06e376d6a7fae", null ],
    [ "class_nameget", "group__class.html#ga32dab29dac27195676d8edfed8e04798", null ],
    [ "class_new", "group__class.html#ga3450d7e28cb57dc3819486ff49f019c7", null ],
    [ "class_obexoffset_get", "group__class.html#ga237b86f879e3eb3edbf674ffccc1f97c", null ],
    [ "class_obexoffset_set", "group__class.html#ga55ca4872991242c991b8bf6adb9bf6a6", null ],
    [ "class_register", "group__class.html#ga0709af4aad9570f0cb91711a5c6d34d1", null ],
    [ "class_subclass", "group__class.html#ga0cc91b6a57713fe7a32a97c85f5f3ee7", null ],
    [ "class_super_construct", "group__class.html#gaed8837dacab7138001ca7b3839a74101", null ],
    [ "ext_main", "group__class.html#ga2fa22e46d14006d0de5cde70af1f6221", null ]
];