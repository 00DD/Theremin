var group__presets =
[
    [ "preset_int", "group__presets.html#gabb360be027245770f96cee996c2759be", null ],
    [ "preset_set", "group__presets.html#ga674fc850c6409a1c25a2519237d801ed", null ],
    [ "preset_store", "group__presets.html#ga5f6d86fdc24e371604b764e7581a4fcb", null ]
];