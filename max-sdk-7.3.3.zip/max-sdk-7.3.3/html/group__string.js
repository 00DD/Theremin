var group__string =
[
    [ "t_string", "structt__string.html", null ],
    [ "string_append", "group__string.html#ga0a4d2ce6b5e97ffc979e39414fe209d0", null ],
    [ "string_chop", "group__string.html#gaba770ef0ed83c9c8d69943456173529b", null ],
    [ "string_getptr", "group__string.html#ga1d65f5effcf8d1f77b45f2603280887d", null ],
    [ "string_new", "group__string.html#ga9fce58b43883b838697077fc674a48d9", null ],
    [ "string_reserve", "group__string.html#gac503901ebf6cd7900798aa8bad1772d2", null ]
];