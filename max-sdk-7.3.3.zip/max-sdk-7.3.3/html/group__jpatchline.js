var group__jpatchline =
[
    [ "jpatchline_get_box1", "group__jpatchline.html#ga64a77181748a3f07c149942ef60053c9", null ],
    [ "jpatchline_get_box2", "group__jpatchline.html#ga8785673e61f9b9406e4c77df1b7781b1", null ],
    [ "jpatchline_get_color", "group__jpatchline.html#ga9f612329fb1b675345173e56b0da8b5e", null ],
    [ "jpatchline_get_endpoint", "group__jpatchline.html#gae3975e752f1b21493cd7546d081e82ab", null ],
    [ "jpatchline_get_hidden", "group__jpatchline.html#gaece283402d2f063de0fec372e7ad8fa5", null ],
    [ "jpatchline_get_inletnum", "group__jpatchline.html#ga01dc2867e149ca5d165a5efd852b80b0", null ],
    [ "jpatchline_get_nextline", "group__jpatchline.html#ga1aed89ce61ea59fbc47a282e25398aa8", null ],
    [ "jpatchline_get_nummidpoints", "group__jpatchline.html#ga42dc7b0cc71d75625f6580987a61f0e9", null ],
    [ "jpatchline_get_outletnum", "group__jpatchline.html#ga901d26a483f28768c842defe9ad06cfb", null ],
    [ "jpatchline_get_startpoint", "group__jpatchline.html#ga22e58d4f810941cbcab9c72fd6f944a8", null ],
    [ "jpatchline_set_color", "group__jpatchline.html#ga711fb3e7a43bbfbd6922f3ac60ba7d86", null ],
    [ "jpatchline_set_hidden", "group__jpatchline.html#gae5bd6fbfa02559350ee2b117a55b64d5", null ]
];