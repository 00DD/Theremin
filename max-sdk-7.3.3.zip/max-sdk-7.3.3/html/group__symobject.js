var group__symobject =
[
    [ "t_symobject", "structt__symobject.html", [
      [ "flags", "structt__symobject.html#a6e4b87b05762ec56b8b78c269211f3b8", null ],
      [ "obj", "structt__symobject.html#a73fa127160cd11d7111eb0b75f15a649", null ],
      [ "sym", "structt__symobject.html#aebafd62d2b8ac1273c32e17b767b999b", null ],
      [ "thing", "structt__symobject.html#a5c2e6a714af33eee38dac5a9261dfa23", null ]
    ] ],
    [ "symobject_linklist_match", "group__symobject.html#gaff1afdf1da1b882e7314874bbf44921e", null ],
    [ "symobject_new", "group__symobject.html#gac66ae5925bb38fa0914f14dcc8172e2d", null ]
];