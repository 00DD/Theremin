var group__atombuf =
[
    [ "t_atombuf", "structt__atombuf.html", [
      [ "a_argc", "structt__atombuf.html#a10cd45d77731a9d19a5797229a11ef07", null ],
      [ "a_argv", "structt__atombuf.html#afcee8d49c0cdaa83cd14c4c2dff44be6", null ]
    ] ],
    [ "atombuf_free", "group__atombuf.html#ga2c10483e31d84a12a037d154bd4051bd", null ],
    [ "atombuf_new", "group__atombuf.html#ga04321578728b852a6dc058516839ce26", null ],
    [ "atombuf_text", "group__atombuf.html#gada864b7fc2e47dbdbef3176de00924a2", null ]
];