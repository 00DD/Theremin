var group__datatypes =
[
    [ "Atoms", "group__atom.html", "group__atom" ],
    [ "Atombufs", "group__atombuf.html", "group__atombuf" ],
    [ "Binbufs", "group__binbuf.html", "group__binbuf" ],
    [ "Symbols", "group__symbol.html", "group__symbol" ],
    [ "t_rect", "structt__rect.html", [
      [ "height", "structt__rect.html#aca22f5c74590cfbbc24c75dd432e5f75", null ],
      [ "width", "structt__rect.html#ab847deccce398dc299128046647413d9", null ],
      [ "x", "structt__rect.html#a00bdba29ffed1459c10dd6e988e5579c", null ],
      [ "y", "structt__rect.html#aa6c75c93ad7a0cb4ff0834f6e0b2a723", null ]
    ] ],
    [ "t_pt", "structt__pt.html", [
      [ "x", "structt__pt.html#abd1171389dfefa1b2cfc94c99e758936", null ],
      [ "y", "structt__pt.html#a1876ee367c9ff280c0710918d4ce8d3b", null ]
    ] ],
    [ "t_size", "structt__size.html", [
      [ "height", "structt__size.html#aa7ec2bdc3c47d9e01bffdab3c63b3112", null ],
      [ "width", "structt__size.html#ae9a82c72ca8a72cdf94685a9cb2e1ef6", null ]
    ] ],
    [ "gimmeback_meth", "group__datatypes.html#ga9942fa14a64084fb30a92a9ace57b3c9", null ],
    [ "method", "group__datatypes.html#ga4b2c39d5bd0b08acd10bffed77f0e513", null ],
    [ "one_meth", "group__datatypes.html#ga2fba91191d852d779ccafd7a0d808a96", null ],
    [ "t_intmethod", "group__datatypes.html#gaa7a0a81f1e809866db67b43eb6a967a5", null ],
    [ "two_meth", "group__datatypes.html#ga0143376f695266d29a16170631267a3e", null ],
    [ "zero_meth", "group__datatypes.html#ga8552ad27c1d2770e99ae94a7cdc87d0e", null ]
];