var group__jsvg =
[
    [ "jsvg_create_from_file", "group__jsvg.html#ga3b185fbdeba32bc51a9935a91a97eba5", null ],
    [ "jsvg_create_from_resource", "group__jsvg.html#ga1c2545a3afc0538ead5aa46903bad73d", null ],
    [ "jsvg_create_from_xmlstring", "group__jsvg.html#gae8173348a7e250c0e762438a75dacee3", null ],
    [ "jsvg_destroy", "group__jsvg.html#ga4b65c02fa6c10d1a9c6260ec1b30e453", null ],
    [ "jsvg_get_size", "group__jsvg.html#ga84eaba3340526cf8984bb8354993304f", null ],
    [ "jsvg_render", "group__jsvg.html#gab30c5cd674073ae36d226a89f0825ecd", null ]
];