var group__symbol =
[
    [ "t_symbol", "structt__symbol.html", [
      [ "s_name", "structt__symbol.html#ae2bf70cea045897c171f39116bf536c8", null ],
      [ "s_thing", "structt__symbol.html#abd835e42c1c3ef3ed958c22cc73c9e69", null ]
    ] ],
    [ "gensym", "group__symbol.html#ga5d8db08b384aeb76eaee85a15f46fbcb", null ],
    [ "gensym_tr", "group__symbol.html#ga1a39ed66fd8120a6a7d3dc80673cc835", null ]
];