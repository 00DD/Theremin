var group__pfft =
[
    [ "t_pfftpub", "structt__pfftpub.html", [
      [ "x_chain", "structt__pfftpub.html#a141782061afc1857e5496c7a4a9d08af", null ],
      [ "x_ffthop", "structt__pfftpub.html#a8fc252dd43ae7881045a1530b770c1db", null ],
      [ "x_fftindex", "structt__pfftpub.html#a5fa88e6b8dd3c99abaefe1bc9cb316b1", null ],
      [ "x_fftoffset", "structt__pfftpub.html#a7e7e6c74c504ef54d77d61c4a83d060d", null ],
      [ "x_fftsize", "structt__pfftpub.html#a6a316a6c000389091f78d0bf39873af8", null ],
      [ "x_fullspect", "structt__pfftpub.html#aa2549e95d9411644da5774dd175614ef", null ],
      [ "x_parent", "structt__pfftpub.html#aaecc60e8d4157a09878dfac79c37c338", null ],
      [ "x_patcher", "structt__pfftpub.html#a4ebc5bfaf7260dbf8b7be97df00dc04a", null ]
    ] ]
];