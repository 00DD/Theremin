var group__styles =
[
    [ "CLASS_ATTR_STYLE_ALIAS_COMPATIBILITY", "group__styles.html#ga7832fb3f9edef8f97b026bba3b4f485e", null ],
    [ "CLASS_ATTR_STYLE_ALIAS_NOSAVE", "group__styles.html#ga09ef9df97fe3579d894a352e1ec9b20f", null ],
    [ "CLASS_ATTR_STYLE_ALIAS_RGBA_LEGACY", "group__styles.html#gac1f4ed7da8e0a313f7385e080c5dce32", null ],
    [ "CLASS_ATTR_STYLE_RGBA", "group__styles.html#ga13bfb32e82f8e96117be7193319adea3", null ],
    [ "CLASS_ATTR_STYLE_RGBA_NOSAVE", "group__styles.html#ga24c9a4155666cf80b3b7cac2b72f25f9", null ],
    [ "CLASS_ATTR_STYLE_RGBA_PREVIEW", "group__styles.html#ga9e726e644d51e9238794a07dc920e119", null ],
    [ "FILL_ATTR_SAVE", "group__styles.html#ga1880358cd3e9fd6cbb686979439e249b", null ],
    [ "class_attr_setfill", "group__styles.html#ga1cee724bf9cd8c39c44cceb5f617b951", null ],
    [ "class_attr_setstyle", "group__styles.html#gab86edd0b122c7de78268867ae3f10b68", null ],
    [ "class_attr_style_alias", "group__styles.html#ga2641331033ac36daa3326cfe689e14b2", null ],
    [ "class_attr_stylemap", "group__styles.html#ga5fe5b2650b578a55ae747db665564a38", null ],
    [ "jgraphics_attr_fillrect", "group__styles.html#gaeae9d92bfe8123e9d57032faa96e261a", null ],
    [ "jgraphics_attr_setfill", "group__styles.html#ga87bff31a6820a9896239a8c14d8684c6", null ],
    [ "object_attr_getfill", "group__styles.html#ga987100b3ea0bdaf664486bed084c1442", null ],
    [ "object_attr_getfillcolor_atposition", "group__styles.html#gaa521ca33e79c6d1bce40c6e16713b15a", null ]
];