var group__parallelutilmod =
[
    [ "jit_parallel_ndim_calc", "group__parallelutilmod.html#gad3af91109732554c8d7bbdb5b575bdc3", null ],
    [ "jit_parallel_ndim_simplecalc1", "group__parallelutilmod.html#ga86f0d53ddcde42a844507338fedd829e", null ],
    [ "jit_parallel_ndim_simplecalc2", "group__parallelutilmod.html#gaeb6c9b472d61bdda9fd33aa61a36df1f", null ],
    [ "jit_parallel_ndim_simplecalc3", "group__parallelutilmod.html#ga56ab668e990aecaa80cd0d37b8123c36", null ],
    [ "jit_parallel_ndim_simplecalc4", "group__parallelutilmod.html#gaa8c8a53219e8e31057fdf4cea80e8081", null ]
];