var group__jmatrix =
[
    [ "t_jmatrix", "structt__jmatrix.html", [
      [ "x0", "structt__jmatrix.html#a891b939bc96d8da496d91969fb713c3f", null ],
      [ "xx", "structt__jmatrix.html#a29290e7f05f04a5400af71b8446b7ee9", null ],
      [ "xy", "structt__jmatrix.html#a9ec039fd31437fe0f1942860aaac65d7", null ],
      [ "y0", "structt__jmatrix.html#ac02c1cf0fe2beab8f56c2f515477e7c8", null ],
      [ "yx", "structt__jmatrix.html#a093abb2306917cadf3c6451ae830bd0a", null ],
      [ "yy", "structt__jmatrix.html#a72a06e5fc831f59dc7d9c05998de0407", null ]
    ] ],
    [ "jgraphics_matrix_init", "group__jmatrix.html#gafb24446d0616fbfca7d8bb96ba97b4ef", null ],
    [ "jgraphics_matrix_init_identity", "group__jmatrix.html#ga7f07986602f12117cfd79e82fb1338d7", null ],
    [ "jgraphics_matrix_init_rotate", "group__jmatrix.html#gaa2e4de77693076fab80df039bb56990e", null ],
    [ "jgraphics_matrix_init_scale", "group__jmatrix.html#ga1f8e9b71bc22f3744643cc25d24f0ac4", null ],
    [ "jgraphics_matrix_init_translate", "group__jmatrix.html#gad5a50cfd545eaec3cf4adb02bb4f4995", null ],
    [ "jgraphics_matrix_invert", "group__jmatrix.html#gae46840f2ac22aee22c9b211d60f4b381", null ],
    [ "jgraphics_matrix_multiply", "group__jmatrix.html#ga496e878760928eaa1226a3ddf7e265a7", null ],
    [ "jgraphics_matrix_rotate", "group__jmatrix.html#gabbe882c283d57b37da55cd4d069b55dc", null ],
    [ "jgraphics_matrix_scale", "group__jmatrix.html#gaac1ee9b0dc5e54cc0cb8e5a213df1b51", null ],
    [ "jgraphics_matrix_transform_point", "group__jmatrix.html#gae2fbe033e0d1cae567b9cea4c4c8c91d", null ],
    [ "jgraphics_matrix_translate", "group__jmatrix.html#gaf39440de92c4e2164d233761af8ba4b9", null ]
];