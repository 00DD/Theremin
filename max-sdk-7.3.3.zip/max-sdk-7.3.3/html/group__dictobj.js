var group__dictobj =
[
    [ "dictobj_atom_safety", "group__dictobj.html#gaf42c50812bf8215eda9bcb0595ecf213", null ],
    [ "dictobj_atom_safety_flags", "group__dictobj.html#ga4a857a7c9c5d852126c87e5a8968a1a7", null ],
    [ "dictobj_dictionaryfromatoms", "group__dictobj.html#gaf964a2f32065e8812d829f02c82c30e8", null ],
    [ "dictobj_dictionaryfromatoms_extended", "group__dictobj.html#ga82cc38d56453709803fa28c9c73f6000", null ],
    [ "dictobj_dictionaryfromstring", "group__dictobj.html#ga2be1d029e50234dd6271736898066403", null ],
    [ "dictobj_dictionarytoatoms", "group__dictobj.html#gadd31e868cc743ffbd216a6be4f074d76", null ],
    [ "dictobj_findregistered_clone", "group__dictobj.html#gaf490af832d2059b1ff1cc8a3c34f1e4c", null ],
    [ "dictobj_findregistered_retain", "group__dictobj.html#gaa95f7a94044a2c1bea5f4b84fc2f5620", null ],
    [ "dictobj_jsonfromstring", "group__dictobj.html#gad9a5d441174d5fa9fd90d40faf82363f", null ],
    [ "dictobj_key_parse", "group__dictobj.html#gaab95c02717e7bd42d089c34d2b30715f", null ],
    [ "dictobj_namefromptr", "group__dictobj.html#ga82b86e621c2e9a280d0ed266710a1a76", null ],
    [ "dictobj_outlet_atoms", "group__dictobj.html#ga6b50af649740589d8a86c114d8499621", null ],
    [ "dictobj_register", "group__dictobj.html#gaa969bb93c3259b7346ac4010becb22e4", null ],
    [ "dictobj_release", "group__dictobj.html#ga893bb067b41415d9a665f0d8087f7c76", null ],
    [ "dictobj_unregister", "group__dictobj.html#ga00aafb1e4ce7b94bd7a73b3620342a8c", null ],
    [ "dictobj_validate", "group__dictobj.html#ga16fa5b430f0116b582d0909604d34a67", null ]
];